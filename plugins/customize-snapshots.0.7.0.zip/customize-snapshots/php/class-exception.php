<?php
/**
 * Customize Snapshot Exceptions.
 *
 * @package CustomizeSnapshots
 */

namespace CustomizeSnapshots;

/**
 * Plugin Exception class.
 */
class Exception extends \Exception {}
